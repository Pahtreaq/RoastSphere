//config default
export const firebaseConfig = {
    apiKey: "AIzaSyA9tJ1p8iDcYy6tLoOisnr4zXFbS8aHEag",
    authDomain: "restaurant-1440e.firebaseapp.com",
    databaseURL: "https://restaurant-1440e.firebaseio.com",
    projectId: "restaurant-1440e",
    storageBucket: "restaurant-1440e.appspot.com",
    messagingSenderId: "314198464457"
};


  // Sandip's firebase configuration
// export const firebaseConfig = { 
//     apiKey: "AIzaSyAzusy10a0pSk-huxJO-DUtK0RoGgqJcpM",
//     authDomain: "restaurantweb-ionic-app.firebaseapp.com",
//     databaseURL: "https://restaurantweb-ionic-app.firebaseio.com",
//     projectId: "restaurantweb-ionic-app",
//     storageBucket: "restaurantweb-ionic-app.appspot.com",
//     messagingSenderId: "120142074708"
//   };

