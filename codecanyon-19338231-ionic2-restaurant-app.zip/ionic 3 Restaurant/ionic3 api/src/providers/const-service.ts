export class ConstService {

    base_url = 'https://restaurantrestapi.herokuapp.com/';

    //base_url= 'http://192.168.1.19:8000/'
    //'https://restaurantrestapi.herokuapp.com/'


}
