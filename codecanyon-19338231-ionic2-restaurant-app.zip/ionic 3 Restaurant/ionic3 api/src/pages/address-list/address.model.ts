export class Address {
  
}